package pl.burningice.plugins.image.file

import org.springframework.web.multipart.MultipartFile
import javax.media.jai.*
import com.sun.media.jai.codec.*

/**
 * Representing image file upladed na server as a MultipartFile
 *
 * @author pawel.gdula@burningice.pl
 */
private class MultipartImageFile extends ImageFile {

    def MultipartImageFile(MultipartFile source) {
        this.source = source
    }

    def getAsJaiStream() {
        JAI.create("stream", new ByteArraySeekableStream(source.bytes))
    }

    def getSourceFileName() {
        source.originalFilename
    }

    def asLocal(outputFilePath) {
        def outputFile = new FileOutputStream(outputFilePath);
        JAI.create('encode', getAsJaiStream(), outputFile, encoder, null);
        outputFile.close()
        ImageFileFactory.produce(new File(outputFilePath))
    }
}