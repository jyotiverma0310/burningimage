package pl.burningice.plugins.image.engines

import pl.burningice.plugins.image.engines.scale.*
import pl.burningice.plugins.image.engines.watermark.DefaultWatermarkEngine

/**
 * Object allows to build chains of action
 * It instance is pass as a parameter to closure that user define and
 * pass to execute method as aparameter
 *
 * @author pawel.gdula@burningice.pl
 */
class ActionBuilder {

    def loadedImage

    def outputFilePath

    def scaleApproximate(width, height) {
        if (!width || !height
            || width <= 0 || height <= 0){
            throw new IllegalArgumentException()
        }

        loadedImage = ScaleEngineFactory.produce(ScaleEngineFactory.APPROXIMATE_ENGINE)
                                        .execute(loadedImage, width, height, outputFilePath)
        outputFilePath
    }

    def scaleAccurate(width, height) {
        if (!width || !height
            || width <= 0 || height <= 0){
            throw new IllegalArgumentException()
        }

        loadedImage = ScaleEngineFactory.produce(ScaleEngineFactory.ACCURATE_ENGINE)
                                        .execute(loadedImage, width, height, outputFilePath)
        outputFilePath
    }

    def watermark(watermarkPath, position = [:], alpha = 1) {
        if (!watermarkPath
            || (position['left'] != null && position['right'] != null)
            || (position['top'] != null && position['bottom'] != null)){
            throw new IllegalArgumentException()
        }

        def watermarkFile = new File(watermarkPath)

        if (!watermarkFile.exists()){
            throw new FileNotFoundException()
        }

        loadedImage = new DefaultWatermarkEngine().execute(watermarkFile, loadedImage, outputFilePath, position, alpha)
        outputFilePath
    }
}

