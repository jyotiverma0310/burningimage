package pl.burningice.plugins.image

import org.springframework.web.multipart.MultipartFile
import  pl.burningice.plugins.image.file.*
import  pl.burningice.plugins.image.engines.*

/**
 * Main entry for the plugin
 *
 * @author pawel.gdula@burningice.pl
 */
class BurningImageService {

    boolean transactional = false

    /**
     * Global setting for output direcotry
     *
     * @var String
     */
    private def resultDir

    /**
     * Object representin image to manipulate
     *
     * @var ImageFile
     */
    private def loadedImage

    /**
     * Allows to load image from spcified local source
     *
     * @throws IllegalArgumentException
     * @throws FileNotFoundException
     * @param String filePath Path to image
     * @return BurningImageService
     */
    def loadImage(String filePath) {
        if (!filePath) {
            throw new IllegalArgumentException()
        }

        def file = new File(filePath)

        if (!file.exists()) {
            throw new FileNotFoundException()
        }

        loadedImage = ImageFileFactory.produce(file)
        this
    }

    /**
     * Allows to load image from uploaded file
     *
     * @throws IllegalArgumentException
     * @throws FileNotFoundException
     * @param String filePath Path to image
     * @return BurningImageService
     */
    def loadImage(MultipartFile file) {
        if (!file) {
            throw new IllegalArgumentException()
        }

        if (file.isEmpty()) {
            throw new FileNotFoundException()
        }

        loadedImage = ImageFileFactory.produce(file)
        this
    }

    /**
     * Methods allows to set global setting for output direcotry
     *
     * @throws IllegalArgumentException
     * @throws FileNotFoundException
     * @param String resultDir Path to direcotry where images should be saved
     * @return BurningImageService
     */
    def resultDir(String resultDir){
        if (!resultDir) {
            throw new IllegalArgumentException()
        }

        if (!(new File(resultDir).exists())) {
            throw new FileNotFoundException()
        }

        if (resultDir[-1] == '/'){
            resultDir = resultDir[0..-2]
        }

        this.resultDir = resultDir
        this
    }

    /**
     * Methods execute action on image
     *
     * @param Closure chain Chain of action on image
     * @return BurningImageService
     */
    def execute (chain) {
        def outputFilePath = "${resultDir}/${loadedImage.name}"
        chain(new ActionBuilder(loadedImage:loadedImage, outputFilePath: outputFilePath))
        this
    }

    /**
     * Methods execute action on image
     *
     * @param String Name of output image (without extension)
     * @param Closure chain Chain of action on image
     * @return BurningImageService
     */
    def execute (outputFileName, chain) {
        def outputFilePath = "${resultDir}/${outputFileName}.${loadedImage.extension}"
        chain(new ActionBuilder(loadedImage:loadedImage, outputFilePath: outputFilePath))
        this
    }
}
