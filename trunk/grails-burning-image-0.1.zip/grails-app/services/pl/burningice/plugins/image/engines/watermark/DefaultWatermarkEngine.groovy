package pl.burningice.plugins.image.engines.watermark

import pl.burningice.plugins.image.file.LocalImageFile
import javax.imageio.ImageIO
import java.awt.AlphaComposite
import pl.burningice.plugins.image.file.ImageFileFactory

/**
 *
 * @author gdulus
 */
class DefaultWatermarkEngine {

    def execute(watermarkFile, loadedImage, outputFilePath, position, alpha) {
        // this engine work onlny on local saved file
        if (!loadedImage.isLocal()) {
            loadedImage = loadedImage.asLocal(outputFilePath)
        }

        def fileToMark = ImageIO.read(loadedImage.source);
        def watermark = ImageIO.read(watermarkFile)
        def (left, top) = transfromPostionon(watermark, fileToMark, position)

        def g = fileToMark.createGraphics();
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)alpha));
        g.drawImage(watermark, (int)left, (int)top, null);
        g.dispose();

        File outputfile = new File(outputFilePath);
        ImageIO.write(fileToMark, loadedImage.extension, outputfile);

        ImageFileFactory.produce(outputfile)
    }

    private def transfromPostionon(watermark, fileToMark, position){
        // standard coordinates
        if (position['left'] != null && position['top'] != null) {
            return [position['left'],
                    position['top']]
        }
        // reversed coordinates
        if (position['right'] != null && position['bottom'] != null) {
            return [fileToMark.width - position['right'] - watermark.width,
                    fileToMark.height - position['bottom'] - watermark.height]
        }
        // no coordinates - center
        [(fileToMark.width - watermark.width)/2,
         (fileToMark.height - watermark.height)/2]
    }
}

