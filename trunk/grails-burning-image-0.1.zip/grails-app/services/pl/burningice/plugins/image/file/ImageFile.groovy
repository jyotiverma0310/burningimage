package pl.burningice.plugins.image.file

/**
 * Interface for all image source (File, MultipartFile)
 *
 * @author pawel.gdula@burningice.pl
 */
abstract class ImageFile {

    private static final def GIF_OUTPUT_FORMAT = 'jpg'

    def source

    @Lazy
    def extensionEncoderMapping = [
        'jpg': 'JPEG',
        'gif': 'JPEG',
        'bmp': 'BMP',
        'png': 'PNG'
    ]

    abstract def getAsJaiStream()

    abstract def getSourceFileName()

    def isLocal() {
        this instanceof LocalImageFile
    }

    def getName() {
        // this action is done to fix name of output file
        // for gif images
        // @see
        // http://java.sun.com/products/java-media/jai/forDevelopers/jaifaq.html
        // "What image file formats are supported? What limitations do these have?"
        def parts = sourceFileName.split(/\./)
        parts[-1] = extension
        parts.join('.')
    }

    def getExtension() {
        def fileExtension = sourceFileName.split(/\./)[-1].toLowerCase()

        if (fileExtension == 'gif') {
            return GIF_OUTPUT_FORMAT
        }

        fileExtension
    }

    def getEncoder() {
        extensionEncoderMapping[extension]
    }
}

