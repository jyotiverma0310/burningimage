package pl.burningice.plugins.image.file

import org.springframework.web.multipart.MultipartFile
import javax.media.jai.*
import com.sun.media.jai.codec.*

/**
 * Representing files stored locally on the disk
 *
 * @author pawel.gdula@burningice.pl
 */
private class LocalImageFile extends ImageFile {

    def LocalImageFile(File source) {
        this.source = source
    }

    def getAsJaiStream() {
        JAI.create("stream", new FileSeekableStream(source))
    }

    def getSourceFileName() {
        source.name
    }
}