package pl.burningice.plugins.image.engines.scale

/**
 * Factory for scale engines 
 *
 * @author Pawel Gdula <pawel.gdula@burningice.pl>
 */
private class ScaleEngineFactory {

    def static final APPROXIMATE_ENGINE = 1;

    def static final ACCURATE_ENGINE = 2;

    def static produce(engineType) {
        if (engineType == APPROXIMATE_ENGINE) {
            return new ApproximateScaleEngine()
        }
        return new AccurateScaleEngine()
    }
}

