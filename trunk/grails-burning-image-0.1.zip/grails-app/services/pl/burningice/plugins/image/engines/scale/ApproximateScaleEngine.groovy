package pl.burningice.plugins.image.engines.scale

import java.awt.image.renderable.ParameterBlock
import javax.media.jai.*;
import com.sun.media.jai.codec.*;

/**
 * Class allows to scale image with approximate width and height
 * Result image will not contain exact width and height gived by user
 * if there will be image deformation
 *
 * @author Pawel Gdula <pawel.gdula@burningice.pl>
 */
private class ApproximateScaleEngine extends ScaleEngine {

    protected def scaleImage(image, width, height) {
        def scaleX = width / image.width
        def scaleY = height / image.height
        def scale = (scaleX > scaleY ? scaleY : scaleX)

        ParameterBlock params = new ParameterBlock();
        params.addSource(image);
        params.add((double)scale);    
        params.add((double)scale);   
        params.add(new InterpolationNearest());

        JAI.create('SubsampleAverage', params, null);
    }
}

