package pl.burningice.plugins.image.file

import org.springframework.web.multipart.MultipartFile

/**
 * Produce ImageFile object depends on source
 *
 * @author pawel.gdula@burningice.pl
 */
class ImageFileFactory {

    static ImageFile produce(File source) {
        new LocalImageFile(source)
    }

    static ImageFile produce(MultipartFile source) {
        new MultipartImageFile(source)
    }
}

