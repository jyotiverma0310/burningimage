package pl.burningice.plugins.image.engines.scale

import pl.burningice.plugin.magick.exceptions.*
import pl.burningice.plugin.magick.scale.exceptions.*
import pl.burningice.plugin.magick.utils.*
import javax.media.jai.*
import com.sun.media.jai.codec.*
import java.awt.image.renderable.ParameterBlock
import javax.imageio.ImageIO
import java.awt.AlphaComposite
import pl.burningice.plugins.image.file.ImageFileFactory

/**
 * Abstract class for all scale engines
 *
 * @author Pawel Gdula <pawel.gdula@burningice.pl>
 */
abstract class ScaleEngine {

    def execute(loadedImage, width, height, outputFilePath) {
        def scaledImage = scaleImage(loadedImage.getAsJaiStream(), width, height)
        def outputFile = new FileOutputStream(outputFilePath);
        JAI.create('encode', scaledImage, outputFile, loadedImage.encoder, null);
        outputFile.close()
        ImageFileFactory.produce(new File(outputFilePath))
    }

    abstract protected def scaleImage(image, width, height)
}

