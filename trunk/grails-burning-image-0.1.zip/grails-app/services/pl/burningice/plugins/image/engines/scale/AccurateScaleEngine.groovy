package pl.burningice.plugins.image.engines.scale

import java.awt.image.renderable.ParameterBlock
import javax.media.jai.*;
import com.sun.media.jai.codec.*;

/**
 * Class allows to scale image with accourate width and height.
 * Result image will  contain exact width and height gived by user,
 * if orginal size of image not fit to user width and height, image will be scaled
 * to shortest side and cropet on center
 *
 * @author Pawel Gdula <pawel.gdula@burningice.pl>
 */
private class AccurateScaleEngine extends ScaleEngine {

    protected def scaleImage(image, width, height) {
        def scaleX = width / image.width
        def scaleY = height / image.height

        def scale = (scaleX < scaleY ? scaleY : scaleX)

        ParameterBlock scaleParams = new ParameterBlock();
        scaleParams.addSource(image);
        scaleParams.add((double)scale);
        scaleParams.add((double)scale);
        scaleParams.add(new InterpolationNearest());

        def scaledImage = JAI.create('SubsampleAverage', scaleParams, null);
        
        if (scaledImage.width ==  width
            && scaledImage.height == height ){
            return scaledImage
        }

        ParameterBlock cropParams = new ParameterBlock();
        cropParams.addSource(scaledImage);
        cropParams.add(scaledImage.width > width ? (float) Math.floor((scaledImage.width - width) / 2) : 0f)
        cropParams.add(scaledImage.height > height ? (float) Math.floor((scaledImage.height - height) / 2) : 0f)
        cropParams.add((float) width)
        cropParams.add((float) height)

        JAI.create('crop', cropParams)
    }
}

